import os
import requests
from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd

app = Flask(__name__)
CORS(app)

WEATHER_API_KEY = os.environ.get("OPENWEATHER_API_KEY", "your-api-key")
WEATHER_API_URL = "http://api.openweathermap.org/data/2.5/weather"

# Loading medicine dataset
medicine_data = pd.read_csv("medicine_dataset.csv")

# Mapping symptoms to dataset indications
SYMPTOM_TO_INDICATION = {
    "headache": "Pain",
    "pain": "Pain",
    "fever": "Fever",
    "cold": "Infection",
    "infection": "Infection",
    "wound": "Wound",
    "fungus": "Fungus",
    "diabetes": "Diabetes",
    "depression": "Depression",
    "virus": "Virus"
}

HEALTH_TIPS = [
    "Stay hydrated by drinking at least 8 glasses of water daily.",
    "Take short walks to improve circulation and mood.",
    "Eat a balanced diet with plenty of fruits and vegetables.",
    "Get 7-8 hours of sleep to support overall health.",
    "Practice deep breathing to reduce stress."
]

JOKES = [
    "Why don't skeletons fight each other? They don't have the guts!",
    "What do you call a bear with no socks on? Barefoot!",
    "Why did the tomato turn red? Because it saw the salad dressing!",
    "What do you call a dinosaur that takes care of its teeth? A Flossiraptor!",
    "Why can't basketball players go on vacation? Because they would get called for traveling!"
]

@app.route("/api/ask", methods=["POST"])
def ask():
    data = request.get_json()
    query = data.get("query", "").lower().strip()

    if "weather" in query:
        city = query.replace("weather in", "").replace("weather", "").strip() or "London"
        try:
            response = requests.get(f"{WEATHER_API_URL}?q={city}&appid={WEATHER_API_KEY}&units=metric")
            response.raise_for_status()
            weather_data = response.json()
            description = weather_data["weather"][0]["description"]
            temp = weather_data["main"]["temp"]
            return jsonify({"response": f"The weather in {city} is {description} with a temperature of {temp}°C."})
        except requests.RequestException as e:
            return jsonify({"response": f"Sorry, I couldn't fetch the weather for {city}. Please try again later."}), 500
    elif any(keyword in query for keyword in ["tip", "health", "healthy", "advice"]):
        from random import choice
        return jsonify({"response": choice(HEALTH_TIPS)})
    elif any(keyword in query for keyword in ["joke", "laugh", "funny"]):
        from random import choice
        return jsonify({"response": choice(JOKES)})
    else:
        return jsonify({"response": "I'm not sure how to help with that. Try asking about the weather, a health tip, a joke, or a medicine!"})

@app.route("/api/medicines", methods=["POST"])
def get_medicines_for_symptom():
    data = request.get_json()
    symptom = data.get("symptom", "").lower().strip()
    indication = SYMPTOM_TO_INDICATION.get(symptom, None)
    if not indication:
        return jsonify({
            "response": f"No medicines found for {symptom}. Please try another symptom like headache, fever, or infection.",
            "medicines": []
        })
    
    # Filter medicines by indication
    filtered_meds = medicine_data[medicine_data["Indication"] == indication].copy()
    if filtered_meds.empty:
        return jsonify({
            "response": f"No medicines found for {symptom} in the dataset.",
            "medicines": []
        })
    
    # Convert Strength to numeric (remove ' mg' and handle non-numeric cases)
    filtered_meds['StrengthNumeric'] = filtered_meds['Strength'].str.replace(' mg', '').astype(float)
    
    # Sort by Classification (OTC first) and Strength (descending)
    filtered_meds['ClassificationRank'] = filtered_meds['Classification'].apply(lambda x: 0 if x == "Over-the-Counter" else 1)
    sorted_meds = filtered_meds.sort_values(by=['ClassificationRank', 'StrengthNumeric'], ascending=[True, False])
    
    # Select top 3 medicines
    top_meds = sorted_meds.head(3)[['Name', 'Dosage Form', 'Strength', 'Classification']].to_dict('records')
    
    # Format response text for voice/display
    response_lines = [f"Here are the top medicines for {symptom}:"]
    for med in top_meds:
        classification = " (Prescription required)" if med["Classification"] == "Prescription" else " (Over-the-Counter)"
        response_lines.append(f"- {med['Name']} ({med['Dosage Form']}, {med['Strength']}){classification}")
    
    return jsonify({
        "response": "\n".join(response_lines),
        "medicines": top_meds
    })

if __name__ == "__main__":
    app.run(debug=True)