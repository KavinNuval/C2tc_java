const express = require("express");
const router = express.Router();

let reminders = [];
let pendingReminder = null; // store last pending reminder if AM/PM missing

// Add reminder
router.post("/add", (req, res) => {
    let { text } = req.body;

    // If user just replied "AM" or "PM"
    if (pendingReminder && (text.toLowerCase() === "am" || text.toLowerCase() === "pm")) {
        const finalReminder = `${pendingReminder} ${text.toUpperCase()}`;
        reminders.push(finalReminder);
        pendingReminder = null;
        return res.json({ message: `Reminder added: "${finalReminder}"` });
    }

    // Normal reminder handling
    const timeMatch = text.match(/\b(\d{1,2})(?:\s*o'?clock)?\b/);

    if (timeMatch) {
        const hour = parseInt(timeMatch[1], 10);

        // If no AM/PM given → ask and keep pending
        if (!text.includes("am") && !text.includes("pm")) {
            pendingReminder = text; 
            return res.json({
                message: `Do you mean ${hour} AM or ${hour} PM?`
            });
        }
    }

    reminders.push(text);
    res.json({ message: `Reminder added: "${text}"` });
});

// Get all reminders
router.get("/", (req, res) => {
    res.json(reminders);
});

module.exports = router;
