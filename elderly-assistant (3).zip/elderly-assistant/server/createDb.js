const mysql = require('mysql2/promise');

async function createDb() {
  const connection = await mysql.createConnection({
    host: 'localhost',
    user: 'your_mysql_user',
    password: 'your_mysql_password',
  });

  await connection.query('CREATE DATABASE IF NOT EXISTS elderly_assistant');
  await connection.query('USE elderly_assistant');

  await connection.query(`
    CREATE TABLE IF NOT EXISTS reminders (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_email VARCHAR(255) NOT NULL,
      medicine VARCHAR(255) NOT NULL,
      time VARCHAR(10) NOT NULL
    )
  `);

  console.log('Database and table created or already exist.');
  await connection.end();
}

createDb().catch(console.error);