// server/server.js
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const remindersRoute = require("./routes/reminders");

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Routes
app.use("/api/reminders", remindersRoute);

const PORT = 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
