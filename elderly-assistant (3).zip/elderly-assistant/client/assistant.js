// === Element refs ===
const micBtn = document.getElementById("micBtn");
const transcriptBox = document.getElementById("transcript");
const assistantResponse = document.getElementById("assistantResponse");

const medicineTab = document.getElementById("medicineTab");
const appointmentTab = document.getElementById("appointmentTab");
const diaryTab = document.getElementById("diaryTab");

const medicineReminders = document.getElementById("medicineReminders");
const appointmentListEl = document.getElementById("appointments");
const diaryList = document.getElementById("diaryList");

const entryType = document.getElementById("entryType");
const nameLabel = document.getElementById("nameLabel");
const dateLabel = document.getElementById("dateLabel");
const timeLabel = document.getElementById("timeLabel");
const entryName = document.getElementById("entryName");
const entryTime = document.getElementById("entryTime");

const recordNewDiaryBtn = document.getElementById("recordNewDiaryBtn");
const diaryRecordModal = document.getElementById("diaryRecordModal");
const diaryEntryName = document.getElementById("diaryEntryName");
const startDiaryRecordBtn = document.getElementById("startDiaryRecordBtn");
const pauseDiaryRecordBtn = document.getElementById("pauseDiaryRecordBtn");
const stopDiaryRecordBtn = document.getElementById("stopDiaryRecordBtn");
const cancelDiaryRecordBtn = document.getElementById("cancelDiaryRecordBtn");

// Modal + lists
const addBtn = document.getElementById("addReminderBtn");
const modal = document.getElementById("reminderModal");
const cancelBtn = document.getElementById("cancelBtn");
const saveBtn = document.getElementById("saveBtn");
const reminderList = document.getElementById("reminderList");
const diary = document.getElementById("diary");

// === Storage ===
let reminders = [];
let appointments = [];
let diaryEntries = [];

// === Speech Recognition (guarded) ===
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.lang = "en-US";
  recognition.interimResults = false;
} else {
  setAssistant("Your browser doesn’t support Speech Recognition. You can still use manual reminders.");
}

// === Voice state ===
let waitingForAMPM = false;
let pendingTimeClarification = null; // { type, name, time("H:MM"), date }
let diaryMediaRecorder;
let diaryAudioChunks = [];
let diaryOverwriteIndex = null; // for re-record

// === Helpers ===
const speak = (text) => {
  try {
    speechSynthesis.cancel(); // prevent overlap
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "en-US";
    u.rate = 0.9;
    u.pitch = 1.05;
    speechSynthesis.speak(u);
  } catch { /* no-op */ }
};
function setAssistant(text, medicines = []) {
  assistantResponse.innerHTML = "";
  if (medicines.length > 0) {
    // Render medicines as an interactive list
    const intro = document.createElement("p");
    intro.className = "text-2xl font-semibold text-gray-800 mb-4";
    intro.textContent = text.split("\n")[0]; // e.g., "Here are the top medicines for headache:"
    assistantResponse.appendChild(intro);

    const ul = document.createElement("ul");
    ul.className = "space-y-3";
    medicines.forEach((med, index) => {
      const li = document.createElement("li");
      li.className = "flex justify-between items-center p-3 bg-blue-100 rounded-lg shadow";
      li.innerHTML = `
        <div class="text-xl text-gray-800">
          ${escapeHtml(med.Name)} (${med['Dosage Form']}, ${med.Strength})${med.Classification === "Prescription" ? " (Rx)" : " (OTC)"}
        </div>
        <button onclick="selectMedicine('${escapeHtml(med.Name)}')" class="bg-indigo-600 text-white text-lg px-4 py-2 rounded hover:bg-indigo-700" title="Select this medicine">Select</button>
      `;
      ul.appendChild(li);
    });
    assistantResponse.appendChild(ul);
  } else {
    // Plain text response for non-medicine queries
    assistantResponse.textContent = text;
  }
}
const monthFormatter = new Intl.DateTimeFormat("en-US", { month: "long" });
const todayMD = () => {
  const d = new Date();
  return `${monthFormatter.format(d)} ${d.getDate()}`;
};
function format12h(h24, m) {
  const ampm = h24 >= 12 ? "PM" : "AM";
  const h = h24 % 12 || 12;
  return `${h}:${String(m).padStart(2, "0")} ${ampm}`;
}
function normalize12h(h, m, ampm) {
  const hh = ((h % 12) || 12);
  return `${hh}:${String(m).padStart(2, "0")} ${ampm}`;
}

// --- Number words up to 59 (enough for typical voice) ---
const NUMS = {
  zero:0, oh:0, one:1, two:2, three:3, four:4, five:5, six:6, seven:7, eight:8, nine:9,
  ten:10, eleven:11, twelve:12, thirteen:13, fourteen:14, fifteen:15, sixteen:16, seventeen:17, eighteen:18, nineteen:19,
  twenty:20, thirty:30, forty:40, fifty:50
};
function wordToNumberPair(w1, w2) {
  const t1 = NUMS[w1]; const t2 = NUMS[w2];
  if (t1 == null && t2 == null) return null;
  if (t1 != null && t1 >= 20 && t2 != null && t2 < 10) return t1 + t2;
  if (t1 != null && (t2 == null)) return t1;
  if ((w1 === "oh" || w1 === "zero") && t2 != null) return t2; // "oh five"
  return null;
}

// --- Parse appointment date like "on October 1st", "on Oct 1", optional suffix ---
function parseDateFromSpeech(s) {
  const m = s.match(/\bon\s+([a-zA-Z]+)\s+(\d{1,2})(?:st|nd|rd|th)?\b/);
  if (!m) return null;
  const month = m[1];
  const day = parseInt(m[2], 10);
  if (!day || day < 1 || day > 31) return null;
  const MonthCap = month.charAt(0).toUpperCase() + month.slice(1).toLowerCase();
  return `${MonthCap} ${day}`;
}

// --- Parse time from speech: supports "at 5", "at 5:15 pm", and "at five fifteen am" ---
function parseTimeFromSpeech(s) {
  let m = s.match(/(?:^|\s)(?:at|@)\s*(\d{1,2})(?:[:. ](\d{1,2}))?\s*(am|pm)?\b/);
  if (m) {
    const h = Math.min(12, Math.max(1, parseInt(m[1], 10)));
    const mm = m[2] != null ? Math.min(59, Math.max(0, parseInt(m[2], 10))) : 0;
    const ampm = m[3] ? m[3].toUpperCase() : null;
    return { h, m: mm, ampm };
  }

  const atIdx = s.indexOf(" at ");
  const atIdx2 = atIdx === -1 ? s.indexOf("@") : atIdx;
  if (atIdx2 !== -1) {
    let chunk = s.slice(atIdx2).replace(/^ (at |@)/, "").trim();
    const onSplit = chunk.split(/\s+on\s+/)[0];
    const ampmM = onSplit.match(/\b(am|pm)\b/);
    const ampm = ampmM ? ampmM[1].toUpperCase() : null;
    const cleaned = onSplit.replace(/\b(am|pm)\b/, "").trim();
    const toks = cleaned.split(/\s+/);
    const hWord = toks[0];
    const mWord = toks[1];

    const hours = wordToNumberPair(hWord, null);
    if (hours != null) {
      let mins = 0;
      if (mWord) {
        const mmCandidate = wordToNumberPair(mWord, toks[2] || null);
        if (mmCandidate != null) mins = Math.min(59, Math.max(0, mmCandidate));
      }
      const h12 = Math.min(12, Math.max(1, hours || 12));
      return { h: h12, m: mins, ampm };
    }
  }

  return null;
}

// --- Parse command intent from speech ---
function parseAddCommand(lowerSpeech) {
  const isAppointment = lowerSpeech.includes("add doctor appointment") || lowerSpeech.includes("add appointment");
  const isReminder = lowerSpeech.includes("add reminder");

  if (!isAppointment && !isReminder) return null;

  let name = lowerSpeech;
  if (isAppointment) {
    name = name.replace("add doctor appointment", "").replace("add appointment", "").trim();
  } else {
    name = name.replace("add reminder", "").trim();
  }

  const timeInfo = parseTimeFromSpeech(lowerSpeech);
  if (!timeInfo) return null;

  const date = isAppointment ? (parseDateFromSpeech(lowerSpeech) || todayMD()) : null;

  name = name.split(" at ")[0].trim();
  if (!name) return null;

  return {
    type: isAppointment ? "appointment" : "medicine",
    name,
    time: timeInfo,
    date
  };
}

// --- Select medicine handler ---
window.selectMedicine = (medicineName) => {
  // Open modal to add as reminder
  modal.classList.remove("hidden");
  entryType.value = "medicine";
  nameLabel.textContent = "Title/Name";
  dateLabel.classList.remove("hidden");
  timeLabel.classList.remove("hidden");
  entryTime.classList.remove("hidden");
  document.getElementById("entryDate").classList.remove("hidden");
  entryName.value = `Take ${medicineName}`;
  entryTime.value = "";
  document.getElementById("entryDate").value = "";
  setAssistant(`Selected ${medicineName}. Enter a time to set a reminder.`);
  speak(`Selected ${medicineName}. Enter a time to set a reminder.`);
};

// === Speech Recognition ===
if (recognition) {
  micBtn.addEventListener("click", () => {
    recognition.start();
    setAssistant("Listening...");
  });

  recognition.onresult = async (event) => {
    const speech = event.results[0][0].transcript;
    transcriptBox.value = speech;
    const lowerSpeech = speech.toLowerCase().trim();
    let reply = "I'm not sure I understand. Try asking about the weather, a health tip, a joke, medicine, or add a reminder/appointment!";
    let medicines = [];

    if (waitingForAMPM) {
      let ampm = null;
      if (lowerSpeech.includes("am") || lowerSpeech.includes("a.m.")) ampm = "AM";
      else if (lowerSpeech.includes("pm") || lowerSpeech.includes("p.m.")) ampm = "PM";

      if (ampm && pendingTimeClarification) {
        const { type, name, time: timeInfo, date } = pendingTimeClarification;
        const timeStr = normalize12h(timeInfo.h, timeInfo.m, ampm);
        const entry = { type, name, time: timeStr, date, notified: false };

        if (type === "medicine") {
          reminders.push(entry);
          saveReminders();
          renderReminders();
        } else {
          appointments.push(entry);
          saveAppointments();
          renderAppointments();
        }
        reply = `Added: ${name} at ${timeStr}${date ? " on " + date : ""}. I'll remind you!`;
        waitingForAMPM = false;
        pendingTimeClarification = null;
      } else {
        reply = "Please say 'AM' or 'PM' to clarify the time.";
        speak(reply);
        setAssistant(reply);
        return;
      }
    }
    else if (lowerSpeech.includes("hello")) {
      reply = "Hello! How can I assist you today?";
    }
    else if (lowerSpeech.includes("time")) {
      reply = "The current time is " + new Date().toLocaleTimeString();
    }
    else if (lowerSpeech.includes("date")) {
      reply = "Today's date is " + new Date().toLocaleDateString();
    }
    else if (lowerSpeech.includes("how are you")) {
      reply = "I’m doing great, thank you for asking!";
    }
    else if (lowerSpeech.includes("add reminder") || lowerSpeech.includes("add doctor appointment") || lowerSpeech.includes("add appointment")) {
      const cmd = parseAddCommand(lowerSpeech);
      if (cmd) {
        const { type, name, time: timeInfo, date } = cmd;
        if (!timeInfo.ampm) {
          pendingTimeClarification = cmd;
          waitingForAMPM = true;
          reply = `Is that ${timeInfo.h}:${String(timeInfo.m).padStart(2, "0")} AM or PM? Please say 'AM' or 'PM'.`;
        } else {
          const timeStr = normalize12h(timeInfo.h, timeInfo.m, timeInfo.ampm.toUpperCase());
          const entry = { type, name, time: timeStr, date, notified: false };
          if (type === "medicine") {
            reminders.push(entry);
            saveReminders();
            renderReminders();
          } else {
            appointments.push(entry);
            saveAppointments();
            renderAppointments();
          }
          reply = `Added: ${name} at ${timeStr}${date ? " on " + date : ""}. I'll remind you!`;
        }
      } else {
        const eg = lowerSpeech.includes("appointment") ? "add doctor appointment Checkup at 5:15 AM on October 1" : "add reminder Take Medicine at 5:15 AM";
        reply = `Please say something like: ${eg}`;
      }
    }
    // Handle symptom queries
    else if (lowerSpeech.includes("medicine") || 
             lowerSpeech.includes("symptom") || 
             lowerSpeech.includes("headache") || 
             lowerSpeech.includes("cold") || 
             lowerSpeech.includes("fever") || 
             lowerSpeech.includes("pain") || 
             lowerSpeech.includes("infection") || 
             lowerSpeech.includes("wound") || 
             lowerSpeech.includes("fungus") || 
             lowerSpeech.includes("diabetes") || 
             lowerSpeech.includes("depression") || 
             lowerSpeech.includes("virus")) {
      try {
        const symptom = ["headache", "cold", "fever", "pain", "infection", "wound", "fungus", "diabetes", "depression", "virus"]
          .find(s => lowerSpeech.includes(s)) || "unknown";
        const response = await fetch("http://localhost:5000/api/medicines", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ symptom })
        });
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();
        reply = data.response;
        medicines = data.medicines || [];
      } catch (error) {
        reply = "Sorry, I couldn't fetch medicine information. Please try again!";
        console.error("Fetch error:", error);
      }
    }
    // Handle health tips and jokes
    else if (lowerSpeech.includes("tip") || 
             lowerSpeech.includes("health") || 
             lowerSpeech.includes("healthy") || 
             lowerSpeech.includes("advice") || 
             lowerSpeech.includes("joke") || 
             lowerSpeech.includes("laugh") || 
             lowerSpeech.includes("funny")) {
      try {
        const response = await fetch("http://localhost:5000/api/ask", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query: speech })
        });
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();
        reply = data.response;
      } catch (error) {
        reply = "Sorry, I couldn't connect to the server. Please try again or ask about the time!";
        console.error("Fetch error:", error);
      }
    }

    setAssistant(reply, medicines);
    speak(reply);
  };

  recognition.onerror = (event) => {
    setAssistant("Error: " + event.error);
    console.error("Speech recognition error:", event.error);
  };
}

// === Storage ===
function loadReminders() {
  const stored = localStorage.getItem("reminders");
  if (stored) reminders = JSON.parse(stored);
  renderReminders();
}
function saveReminders() {
  localStorage.setItem("reminders", JSON.stringify(reminders));
}
function loadAppointments() {
  const stored = localStorage.getItem("appointments");
  if (stored) appointments = JSON.parse(stored);
  renderAppointments();
}
function saveAppointments() {
  localStorage.setItem("appointments", JSON.stringify(appointments));
}
function loadDiaryEntries() {
  const stored = localStorage.getItem("diaryEntries");
  if (stored) {
    try {
      diaryEntries = JSON.parse(stored);
      console.log("Loaded diary entries:", diaryEntries);
    } catch (e) {
      console.error("Error parsing diaryEntries:", e);
      diaryEntries = [];
    }
  }
  renderDiaryEntries();
}
function saveDiaryEntries() {
  try {
    localStorage.setItem("diaryEntries", JSON.stringify(diaryEntries));
    console.log("Saved diary entries:", diaryEntries);
  } catch (e) {
    console.error("Error saving diaryEntries:", e);
    setAssistant("Error saving voice message. Please try again.");
  }
}

// === Modal handlers ===
addBtn.addEventListener("click", () => {
  modal.classList.remove("hidden");
  entryType.value = "medicine";
  nameLabel.textContent = "Title/Name";
  dateLabel.classList.remove("hidden");
  timeLabel.classList.remove("hidden");
  entryTime.classList.remove("hidden");
  document.getElementById("entryDate").classList.remove("hidden");
  entryName.value = "";
  entryTime.value = "";
  document.getElementById("entryDate").value = "";
});

cancelBtn.addEventListener("click", () => {
  modal.classList.add("hidden");
});

entryType.addEventListener("change", () => {
  if (entryType.value === "diary") {
    nameLabel.textContent = "Message Title";
    dateLabel.classList.add("hidden");
    document.getElementById("entryDate").classList.add("hidden");
    timeLabel.classList.add("hidden");
    entryTime.classList.add("hidden");
  } else {
    nameLabel.textContent = "Title/Name";
    dateLabel.classList.remove("hidden");
    document.getElementById("entryDate").classList.remove("hidden");
    timeLabel.classList.remove("hidden");
    entryTime.classList.remove("hidden");
  }
  entryName.placeholder = entryType.value === "diary" ? "e.g., About Family" : entryType.value === "appointment" ? "e.g., Checkup" : "e.g., Take Paracetamol";
});

saveBtn.addEventListener("click", () => {
  const type = entryType.value;
  const name = entryName.value.trim();
  const time = entryTime.value;
  const date = document.getElementById("entryDate").value;
  if (!name || (type !== "diary" && !time) || (type === "appointment" && !date)) {
    alert("Please enter title/name, time (if needed), and date (for appointments).");
    return;
  }
  if (type === "diary") {
    diaryRecordModal.classList.remove("hidden");
    diaryEntryName.value = name;
    modal.classList.add("hidden");
  } else {
    const [hours, minutes] = time.split(':');
    const hourNum = parseInt(hours);
    const ampm = hourNum >= 12 ? 'PM' : 'AM';
    const formattedHour = hourNum % 12 || 12;
    const formattedTime = `${formattedHour}:${minutes} ${ampm}`;
    if (type === "medicine") {
      reminders.push({ type: "medicine", name, time: formattedTime, date: null, notified: false });
      saveReminders();
      renderReminders();
    } else {
      appointments.push({ type: "appointment", name, time: formattedTime, date, notified: false });
      saveAppointments();
      renderAppointments();
    }
    modal.classList.add("hidden");
  }
  entryName.value = "";
  entryTime.value = "";
  document.getElementById("entryDate").value = "";
});

recordNewDiaryBtn.addEventListener("click", () => {
  diaryRecordModal.classList.remove("hidden");
  diaryEntryName.value = "";
  diaryOverwriteIndex = null;
  startDiaryRecordBtn.classList.remove("hidden");
  pauseDiaryRecordBtn.classList.add("hidden");
  stopDiaryRecordBtn.classList.add("hidden");
});

cancelDiaryRecordBtn.addEventListener("click", () => {
  diaryRecordModal.classList.add("hidden");
  if (diaryMediaRecorder && diaryMediaRecorder.state === "recording") {
    diaryMediaRecorder.stop();
    diaryAudioChunks = [];
  }
  diaryOverwriteIndex = null;
});

startDiaryRecordBtn.addEventListener("click", async () => {
  const name = diaryEntryName.value.trim() || "Message";
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    diaryMediaRecorder = new MediaRecorder(stream);
    diaryAudioChunks = [];

    diaryMediaRecorder.ondataavailable = (e) => {
      diaryAudioChunks.push(e.data);
      console.log("Diary audio data received:", e.data.size, "bytes");
    };
    diaryMediaRecorder.onstop = () => {
      if (diaryAudioChunks.length === 0 || diaryAudioChunks.every(chunk => chunk.size === 0)) {
        setAssistant("No audio recorded. Please try again.");
        console.error("No audio data captured");
        return;
      }
      const audioBlob = new Blob(diaryAudioChunks, { type: 'audio/webm' });
      const reader = new FileReader();
      reader.onload = () => {
        const entry = { type: "diary", name, timestamp: new Date().toLocaleString(), audio: reader.result };
        if (diaryOverwriteIndex != null) {
          diaryEntries[diaryOverwriteIndex] = entry;
        } else {
          diaryEntries.push(entry);
        }
        saveDiaryEntries();
        renderDiaryEntries();
        diaryAudioChunks = [];
        diaryRecordModal.classList.add("hidden");
        diaryOverwriteIndex = null;
        setAssistant(`Voice message "${name}" recorded and saved.`);
        speak(`Voice message "${name}" recorded and saved.`);
        console.log("Diary audio saved to localStorage");
      };
      reader.onerror = () => {
        setAssistant("Error saving audio. Please try again.");
        console.error("FileReader error");
      };
      reader.readAsDataURL(audioBlob);
    };
    diaryMediaRecorder.onerror = (event) => {
      setAssistant("Error during recording. Please try again.");
      console.error("Diary MediaRecorder error:", event.error);
    };
    diaryMediaRecorder.start();
    startDiaryRecordBtn.classList.add("hidden");
    pauseDiaryRecordBtn.classList.remove("hidden");
    stopDiaryRecordBtn.classList.remove("hidden");
    setAssistant(`Recording "${name}"...`);
    console.log("Diary recording started");
  } catch (err) {
    console.error("Diary microphone error:", err);
    setAssistant("Error accessing microphone. Please ensure permissions are granted.");
  }
});

pauseDiaryRecordBtn.addEventListener("click", () => {
  if (!diaryMediaRecorder) return;
  if (diaryMediaRecorder.state === "recording") {
    diaryMediaRecorder.pause();
    pauseDiaryRecordBtn.textContent = "Resume";
    setAssistant("Recording paused.");
  } else if (diaryMediaRecorder.state === "paused") {
    diaryMediaRecorder.resume();
    pauseDiaryRecordBtn.textContent = "Pause";
    setAssistant("Recording resumed...");
  }
});

stopDiaryRecordBtn.addEventListener("click", () => {
  if (!diaryMediaRecorder) return;
  if (diaryMediaRecorder.state === "recording" || diaryMediaRecorder.state === "paused") {
    diaryMediaRecorder.stop();
    setAssistant("Recording stopped. Saving message...");
  }
});

// Re-record & delete diary entries
window.reRecordDiaryEntry = (index) => {
  const entry = diaryEntries[index];
  diaryRecordModal.classList.remove("hidden");
  diaryEntryName.value = entry.name;
  diaryOverwriteIndex = index;
  startDiaryRecordBtn.classList.remove("hidden");
  pauseDiaryRecordBtn.classList.add("hidden");
  stopDiaryRecordBtn.classList.add("hidden");
};

window.deleteDiaryEntry = (index) => {
  diaryEntries.splice(index, 1);
  saveDiaryEntries();
  renderDiaryEntries();
};

// Delete reminder/appointment
window.deleteReminder = (index) => {
  reminders.splice(index, 1);
  saveReminders();
  renderReminders();
};

window.deleteAppointment = (index) => {
  appointments.splice(index, 1);
  saveAppointments();
  renderAppointments();
};

// === Tabs ===
function showTab(which) {
  const map = {
    medicine: medicineReminders,
    appointment: appointmentListEl,
    diary: diaryList
  };
  for (const key of Object.keys(map)) {
    if (key === which) {
      map[key].classList.add("active");
      map[key].classList.remove("hidden");
    } else {
      map[key].classList.remove("active");
      map[key].classList.add("hidden");
    }
  }
  const on = (btn) => { btn.classList.add("bg-indigo-100", "text-indigo-800"); btn.classList.remove("bg-gray-100", "text-gray-800"); };
  const off = (btn) => { btn.classList.add("bg-gray-100", "text-gray-800"); btn.classList.remove("bg-indigo-100", "text-indigo-800"); };

  if (which === "medicine") { on(medicineTab); off(appointmentTab); off(diaryTab); }
  if (which === "appointment") { on(appointmentTab); off(medicineTab); off(diaryTab); }
  if (which === "diary") { on(diaryTab); off(medicineTab); off(appointmentTab); }
}

medicineTab.addEventListener("click", () => showTab("medicine"));
appointmentTab.addEventListener("click", () => showTab("appointment"));
diaryTab.addEventListener("click", () => showTab("diary"));

// === Renderers ===
function renderReminders() {
  reminderList.innerHTML = "";
  if (reminders.length === 0) {
    reminderList.innerHTML = '<li class="text-gray-400 text-sm">No reminders yet...</li>';
    return;
  }
  reminders.forEach((r, i) => {
    const li = document.createElement("li");
    li.className = "flex justify-between items-center p-3 bg-indigo-50 rounded-lg shadow";
    li.innerHTML = `
      <div>
        <p class="font-semibold text-lg">${escapeHtml(r.name)}</p>
        <p class="text-sm text-gray-500">⏰ ${r.time}</p>
      </div>
      <button onclick="deleteReminder(${i})" class="text-red-500 hover:text-red-700 text-lg" title="Delete">✖</button>
    `;
    reminderList.appendChild(li);
  });
}

function renderAppointments() {
  appointmentListEl.innerHTML = "";
  if (appointments.length === 0) {
    appointmentListEl.innerHTML = '<li class="text-gray-400 text-sm">No appointments yet...</li>';
    return;
  }
  appointments.forEach((a, i) => {
    const li = document.createElement("li");
    li.className = "flex justify-between items-center p-3 bg-green-50 rounded-lg shadow";
    li.innerHTML = `
      <div>
        <p class="font-semibold text-lg">${escapeHtml(a.name)}</p>
        <p class="text-sm text-gray-500">📅 ${a.date} at ${a.time}</p>
      </div>
      <button onclick="deleteAppointment(${i})" class="text-red-500 hover:text-red-700 text-lg" title="Delete">✖</button>
    `;
    appointmentListEl.appendChild(li);
  });
}

function renderDiaryEntries() {
  diary.innerHTML = "";
  if (diaryEntries.length === 0) {
    diary.innerHTML = '<li class="text-gray-400 text-sm">No voice messages yet...</li>';
    return;
  }
  diaryEntries.forEach((d, i) => {
    const li = document.createElement("li");
    li.className = "flex flex-col p-3 bg-purple-50 rounded-lg shadow";
    li.innerHTML = `
      <div class="flex justify-between items-center mb-2">
        <div>
          <p class="font-semibold text-lg">${escapeHtml(d.name)}</p>
          <p class="text-sm text-gray-500">🎤 ${d.timestamp}</p>
        </div>
        <div class="flex gap-2">
          <button onclick="reRecordDiaryEntry(${i})" class="text-indigo-600 hover:text-indigo-800 text-lg" title="Re-record">🎙️</button>
          <button onclick="deleteDiaryEntry(${i})" class="text-red-500 hover:text-red-700 text-lg" title="Delete">✖</button>
        </div>
      </div>
      <audio controls src="${d.audio}"></audio>
    `;
    diary.appendChild(li);
  });
}

// === Safe text ===
function escapeHtml(s) {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

// === Reminder checks (every minute) ===
setInterval(() => {
  const now = new Date();
  const current = format12h(now.getHours(), now.getMinutes());
  const currentDate = now.toLocaleDateString("en-US", { month: "long", day: "numeric" });

  reminders.forEach(r => {
    if (r.time === current && !r.notified) {
      alert(`🔔 Reminder: ${r.name}`);
      speak(`Reminder: ${r.name}`);
      r.notified = true;
    }
  });
  saveReminders();

  appointments.forEach(a => {
    if (a.date === currentDate && a.time === current && !a.notified) {
      alert(`📅 Doctor Appointment: ${a.name} at ${a.time} on ${a.date}`);
      speak(`Doctor Appointment: ${a.name} at ${a.time} on ${a.date}`);
      a.notified = true;
    }
  });
  saveAppointments();
}, 60000);

// === Init ===
loadReminders();
loadAppointments();
loadDiaryEntries();
showTab("medicine");