
async function loadReminders() {
  try {
    const res = await fetch("http://localhost:5000/api/reminders");
    if (!res.ok) throw new Error("Failed to fetch reminders");

    const reminders = await res.json();
    const container = document.getElementById("reminders-list");

    container.innerHTML = "";
    reminders.forEach(r => {
      const div = document.createElement("div");
      div.textContent = `${r.text} at ${r.time}`;
      container.appendChild(div);
    });
  } catch (err) {
    document.getElementById("reminders-list").innerHTML =
      `<span style="color:red;">Error loading reminders</span>`;
    console.error(err);
  }
}

document.addEventListener("DOMContentLoaded", loadReminders);
